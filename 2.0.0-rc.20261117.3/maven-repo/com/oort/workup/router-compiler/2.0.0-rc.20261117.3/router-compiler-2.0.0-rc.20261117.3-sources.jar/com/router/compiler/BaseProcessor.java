package com.router.compiler;

import com.router.compiler.util.TextUtils;

import javax.annotation.processing.*;
import javax.lang.model.SourceVersion;
import javax.lang.model.element.Element;
import javax.lang.model.util.Elements;
import javax.lang.model.util.Types;
import javax.tools.Diagnostic;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

/**
 * 注解处理器抽象基类。
 * <p>
 * 提供所有注解处理器共有的功能：
 * <ul>
 *     <li>工具类实例（elementUtils, typeUtils, filer, messager）</li>
 *     <li>模块名称的读取和校验</li>
 *     <li>日志输出方法（printMessage, error）</li>
 *     <li>版本和参数配置方法</li>
 * </ul>
 * </p>
 *
 * @author Zhang zhijun on 2026/5/13
 * @version 1.0
 * @since 1.0.0
 */
public abstract class BaseProcessor extends AbstractProcessor {

    // ==================== 工具类实例 ====================

    /**
     * 元素工具类，用于操作类、方法、字段等程序元素
     */
    protected Elements elementUtils;

    /**
     * 类型工具类，用于比较和操作 Java 类型
     */
    protected Types typeUtils;

    /**
     * 文件生成器，用于创建生成的 Java 源文件
     */
    protected Filer filer;

    /**
     * 消息打印器，用于在编译时输出日志信息
     */
    protected Messager messager;

    /**
     * 当前处理的模块名称，从注解处理器参数中获取
     */
    protected String moduleName;

    // ==================== 生命周期方法 ====================

    /**
     * 初始化注解处理器。
     * <p>
     * 初始化工具类，并读取/校验模块名称配置。
     * 子类可以覆盖此方法，但必须调用 {@code super.init(processingEnv)}。
     * </p>
     *
     * @param processingEnv 注解处理环境
     */
    @Override
    public synchronized void init(ProcessingEnvironment processingEnv) {
        super.init(processingEnv);
        elementUtils = processingEnv.getElementUtils();
        typeUtils = processingEnv.getTypeUtils();
        filer = processingEnv.getFiler();
        messager = processingEnv.getMessager();

        // 读取模块名称配置
        Map<String, String> options = processingEnv.getOptions();
        moduleName = options.get(CompilerConsts.KEY_MODULE_NAME);

        // 校验模块名称
        validateModuleName();

        // 清理模块名，只保留字母数字和下划线
        moduleName = moduleName.replaceAll("[^a-zA-Z0-9_]", "");

    }

    /**
     * 校验模块名称是否配置。
     * <p>
     * 若未配置，抛出异常并提示用户配置方法。
     * </p>
     *
     * @throws RuntimeException 当模块名称为空时抛出
     */
    private void validateModuleName() {
        if (TextUtils.isEmpty(moduleName)) {
            String errorMessage = """
                    No module name configured! Please add in build.gradle:
                    android {
                        defaultConfig {
                            javaCompileOptions {
                                annotationProcessorOptions {
                                    arguments = [moduleName: project.getName()]
                                }
                            }
                        }
                    }""";
            throw new RuntimeException(errorMessage);
        }
    }

    // ==================== 辅助方法 ====================

    /**
     * 输出编译时信息日志。
     * <p>
     * 自动添加 {@link CompilerConsts#TAG} 前缀，便于在编译输出中识别 DRouter 的日志。
     * </p>
     *
     * @param kind    日志级别（NOTE、WARNING、ERROR）
     * @param message 日志信息（支持格式化占位符）
     * @param args    格式化参数
     */
    protected void printMessage(Diagnostic.Kind kind, String message, Object... args) {
        if (args.length > 0) {
            message = String.format(message, args);
        }
        messager.printMessage(kind, CompilerConsts.TAG + " " + message);
    }

    /**
     * 输出编译时信息日志，并关联到具体的源代码元素。
     *
     * @param kind    日志级别（NOTE、WARNING、ERROR）
     * @param element 关联的源代码元素
     * @param message 日志信息（支持格式化占位符）
     * @param args    格式化参数
     */
    protected void printMessage(Diagnostic.Kind kind, Element element, String message, Object... args) {
        if (args.length > 0) {
            message = String.format(message, args);
        }
        messager.printMessage(kind, message, element);
    }

    /**
     * 输出编译时错误日志，并关联到具体的源代码元素。
     *
     * @param element 出错的源代码元素
     * @param message 错误信息（支持格式化占位符）
     * @param args    格式化参数
     */
    protected void error(Element element, String message, Object... args) {
        printMessage(Diagnostic.Kind.ERROR, element, message, args);
    }

    // ==================== 元数据方法 ====================

    /**
     * 返回支持的 Java 语言版本。
     *
     * @return 最新的 Java 源码版本
     */
    @Override
    public SourceVersion getSupportedSourceVersion() {
        return SourceVersion.latestSupported();
    }

    /**
     * 返回支持的参数选项。
     * <p>
     * 子类可以覆盖此方法添加更多参数，建议调用 {@code super.getSupportedOptions()} 后添加。
     * </p>
     *
     * @return 包含 {@link CompilerConsts#KEY_MODULE_NAME} 的参数集合
     */
    @Override
    public Set<String> getSupportedOptions() {
        Set<String> options = new LinkedHashSet<>();
        options.add(CompilerConsts.KEY_MODULE_NAME);
        return options;
    }

    /**
     * 格式化生成文件的头注释。
     *
     * @param className  生成的类名
     * @param routeCount 注册的路由数量
     * @return 格式化后的注释字符串
     */
    public String formatComment(String className, int routeCount) {
        return String.format(java.util.Locale.US, """
            Auto-generated by Router annotation processor. DO NOT MODIFY!
            Module: %s
            Generated class: %s
            Registered routes: %d
            Supported types: Activity, Service, RouteHandler
            """,
                moduleName, className, routeCount
        );
    }
}