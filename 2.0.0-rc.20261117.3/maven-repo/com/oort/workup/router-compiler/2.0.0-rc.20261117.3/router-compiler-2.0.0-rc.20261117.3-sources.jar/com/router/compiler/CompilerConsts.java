package com.router.compiler;

/**
 * 编译器常量定义类
 * <p>
 * 集中管理注解处理器使用的所有常量，包括：
 * <ul>
 *     <li>生成的代码包名配置</li>
 *     <li>接口类名引用</li>
 *     <li>日志标签等</li>
 * </ul>
 * </p>
 * <p>
 * 这些常量在 RouterModuleProcessor 和 InterceptorProcessor 中使用，
 * 确保生成的代码与运行时 API 保持一致。
 * </p>
 *
 * @author Zhang zhijun on 2026/5/13 9:39
 * @version 1.0
 */
public class CompilerConsts {

    // ==================== 基础常量 ====================

    /**
     * SDK 名称标识
     */
    public static final String SDK_NAME = "Router";

    /**
     * 日志输出标签，用于编译时日志输出
     */
    public static final String TAG = "[Router Compiler]";

    /**
     * build.gradle 中配置的模块名称参数键
     * <p>
     * 在模块的 build.gradle 中配置：
     * <pre>{@code
     * android {
     *     defaultConfig {
     *         javaCompileOptions {
     *             annotationProcessorOptions {
     *                 arguments = [moduleName: project.getName()]
     *             }
     *         }
     *     }
     * }
     * }</pre>
     */
    public static final String KEY_MODULE_NAME = "moduleName";

    /**
     * 模块路由 基础包名，所有生成类和 API 模块的包名都基于此常量拼接。
     * <p>
     * 修改此值将影响所有生成代码的包路径，需确保与运行时扫描配置一致。
     * </p>
     */
    public static final String BASE_PACKAGE_NAME = "com.router";

    // ==================== 拦截器相关常量 ====================

    /**
     * 拦截器组类生成的目标包名
     * <p>
     * 编译时注解处理器会为每个模块生成一个 Router$$Interceptor$$xxx 类，
     * 这些类统一放在此包下，便于运行时扫描并实例化拦截器链。
     * </p>
     * <p>
     * 示例：com.router.interceptor.Router$$Interceptor$$user
     * </p>
     */
    public static final String INTERCEPTOR_PACKAGE = BASE_PACKAGE_NAME + ".interceptor";

    /**
     * 拦截器组类生成的目标类名前缀
     * <p>
     * 模块注册类会以此前缀开头，并加上模块名称作为类名。
     * </p>
     * <p>
     * 示例：Router$$Interceptor$$user
     * </p>
     */
    public static final String ROUTER_INTERCEPTOR_PREFIX = "Router$$Interceptor$$";

    /**
     * 全局拦截器组类生成的目标类名前缀
     * <p>
     * 全局拦截器组类会以此前缀开头，并加上模块名称作为类名。
     * </p>
     * <p>
     * 示例：Router$$Interceptor$$Global$$app
     * </p>
     */
    public static final String ROUTER_INTERCEPTOR_GLOBAL_PREFIX = ROUTER_INTERCEPTOR_PREFIX + "Global$$";

    /**
     * InterceptorModule 接口的完整类名
     * <p>
     * 拦截器组类需要实现此接口，用于返回该模块下的所有拦截器列表。
     * </p>
     */
    public static final String INTERCEPTOR_MODULE = "com.router.api.interceptor.InterceptorModule";

    /**
     * RouterInterceptor 接口的完整类名
     * <p>
     * 用于编译时校验：被 @Interceptor 注解的类必须实现此接口，
     * 否则编译报错。这是单个拦截器的接口。
     * </p>
     */
    public static final String ROUTER_INTERCEPTOR = "com.router.api.interceptor.RouterInterceptor";

    /**
     * MapUtils 工具类的完整类名
     * <p>
     * 用于将 TreeMap 转换为有序拦截器列表。
     * </p>
     */
    public static final String MAP_UTILS = "com.router.api.utils.MapUtils";

    // ==================== 模块注册相关常量 ====================

    /**
     * 路由模块注册类生成的目标包名
     * <p>
     * 编译时注解处理器会为每个模块生成一个 Router$$Module$$xxx 类，
     * 这些类统一放在此包下，便于运行时通过 ClassUtils 扫描加载。
     * </p>
     * <p>
     * 示例：com.router.register.Router$$Module$$user
     * </p>
     */
    public static final String MODULE_PACKAGE = BASE_PACKAGE_NAME + ".register";

    /**
     * 路由模块注册类生成的目标类名前缀
     * <p>
     * 模块注册类会以此前缀开头，并加上模块名称作为类名。
     * </p>
     * <p>
     * 示例：Router$$Module$$user
     * </p>
     */
    public static final String ROUTER_MODULE_PREFIX = "Router$$Module$$";

    /**
     * 路由模块接口 RouteRegistry 的完整类名
     * <p>
     * 模块注册类需要实现此接口，提供 {@code findHandler} 方法用于查找路由处理器。
     * </p>
     */
    public static final String ROUTE_MODULE = "com.router.api.router.RouteRegistry";

    /**
     * 路由处理接口 RouteAction 的完整类名
     * <p>
     * 用于编译时校验：被 {@code @Route} 注解的类必须实现此接口，
     * 否则编译报错。
     * </p>
     */
    public static final String ROUTE_HANDLER = "com.router.api.router.RouteAction";

    /**
     * 路由包装类 RouteWrapper 的完整类名
     * <p>
     * 用于包装 RouterHandler 类及其元数据（线程模式、路径等），
     * 在生成的 Module 类中用于注册路由处理器。
     * </p>
     */
    public static final String ROUTE_WRAPPER = "com.router.api.extra.RouteWrapper";

    /**
     * ThreadMode 枚举的完整类名
     * <p>
     * 用于指定路由处理器的执行线程模式。
     * 支持的模式：
     * <ul>
     *     <li>POSTING - 当前线程直接执行</li>
     *     <li>MAIN - 主线程执行</li>
     *     <li>BACKGROUND - 后台串行线程执行</li>
     *     <li>ASYNC - 异步线程池并发执行</li>
     * </ul>
     * </p>
     */
    public static final String THREAD_MODE = "com.router.base.ThreadMode";

    /**
     * Activity 启动代理类的完整类名
     * <p>
     * 用于启动被 {@code @Route} 注解的 Activity，
     * 无需为每个 Activity 生成单独的代理类。
     * </p>
     */
    public static final String ACTIVITY_PROXY_ROUTE = "com.router.api.proxy.ActivityProxyRoute";

    /**
     * Service 启动代理类的完整类名
     * <p>
     * 用于启动被 {@code @Route} 注解的 Service，
     * 无需为每个 Service 创建单独的代理类。
     * </p>
     */
    public static final String SERVICE_PROXY_ROUTE = "com.router.api.proxy.ServiceProxyRoute";

}