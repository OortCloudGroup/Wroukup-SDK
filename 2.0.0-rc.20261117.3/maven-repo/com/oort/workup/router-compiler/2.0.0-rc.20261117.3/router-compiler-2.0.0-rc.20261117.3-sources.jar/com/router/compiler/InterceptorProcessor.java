package com.router.compiler;

import com.router.base.annotation.Interceptor;
import com.google.auto.service.AutoService;
import com.squareup.javapoet.ClassName;
import com.squareup.javapoet.JavaFile;
import com.squareup.javapoet.MethodSpec;
import com.squareup.javapoet.ParameterizedTypeName;
import com.squareup.javapoet.TypeSpec;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import javax.annotation.processing.ProcessingEnvironment;
import javax.annotation.processing.Processor;
import javax.annotation.processing.RoundEnvironment;
import javax.lang.model.element.Element;
import javax.lang.model.element.Modifier;
import javax.lang.model.element.TypeElement;
import javax.lang.model.type.TypeMirror;
import javax.tools.Diagnostic;

/**
 * {@link Interceptor} 注解处理器。
 * <p>
 * 在编译时扫描所有被 {@code @Interceptor} 注解标记的拦截器类，验证其合法性，
 * 并为每个模块自动生成对应的拦截器管理类 {@code Router$$Interceptor$$xxx}，
 * 该类实现了 {@code InterceptorModule} 接口。
 * </p>
 *
 * <h3>拦截器说明</h3>
 * <p>
 * 拦截器用于在路由跳转前、后执行自定义逻辑，如登录校验、权限校验、埋点上报等。
 * 生成的拦截器管理类会按优先级顺序返回所有拦截器，优先级越小的越先执行。
 * </p>
 *
 * <h3>生成类命名规则</h3>
 * <pre>
 * 模块名示例：circle
 * 模块拦截器类名：Router$$Interceptor$$circle
 * 全局拦截器类名：Router$$Interceptor$$Global$$circle
 * 包名：com.router.assist.interceptor（模块拦截器）
 * 包名：com.router.assist.global（全局拦截器）
 * </pre>
 *
 * <h3>配置要求</h3>
 * 使用此处理器时，必须通过 {@code annotationProcessorOptions} 配置模块名称：
 * <pre>{@code
 * android {
 *     defaultConfig {
 *         javaCompileOptions {
 *             annotationProcessorOptions {
 *                 arguments = [moduleName: project.getName()]
 *             }
 *         }
 *     }
 * }
 * }</pre>
 *
 * <h3>拦截器优先级规则</h3>
 * <ul>
 *     <li>优先级范围：0 ~ 100，数值越小优先级越高</li>
 *     <li>同一模块内优先级不可重复，否则编译报错</li>
 *     <li>优先级相同时，按注册顺序执行（但由于不允许重复，实际按数值排序）</li>
 * </ul>
 *
 * <h3>典型使用示例</h3>
 * <pre>{@code
 * @Interceptor(priority = 10)
 * public class LoginInterceptor implements RouterInterceptor {
 *     @Override
 *     public void intercept(InterceptorChain chain) {
 *         if (isLoggedIn()) {
 *             chain.proceed(chain.getRouterPost());
 *         } else {
 *             chain.onInterrupt();
 *         }
 *     }
 * }
 * }</pre>
 *
 * <h3>生成的代码示例</h3>
 * <pre>{@code
 * public final class Router$$Interceptor$$circlemodule implements InterceptorModule {
 *     private final Map<RouterInterceptor, Integer> priorityMap;
 *
 *     public Router$$Interceptor$$circlemodule() {
 *         priorityMap = new LinkedHashMap<>();
 *         // Priority: 10
 *         priorityMap.put(new LoginInterceptor(), 10);
 *         // Priority: 20
 *         priorityMap.put(new PermissionInterceptor(), 20);
 *     }
 *
 *     @Override
 *     public List<RouterInterceptor> getInterceptors() {
 *         return Collections.unmodifiableList(new ArrayList<>(priorityMap.keySet()));
 *     }
 *
 *     @Override
 *     public Map<RouterInterceptor, Integer> getPriorityMap() {
 *         return Collections.unmodifiableMap(priorityMap);
 *     }
 * }
 * }</pre>
 *
 * @author Zhang zhijun on 2026/5/13
 * @version 1.0
 */
@AutoService(Processor.class)
public class InterceptorProcessor extends BaseProcessor {

    /**
     * RouterInterceptor 接口的类型镜像，用于类型校验
     * com.router.api.interceptor.RouterInterceptor
     */
    private TypeMirror routerInterceptorType;

    // ==================== 生命周期方法 ====================

    /**
     * 初始化注解处理器。
     * <p>
     * 在处理器实例化后调用，用于初始化编译环境工具类、获取配置参数、校验必要配置。
     * </p>
     *
     * <h3>执行步骤：</h3>
     * <ol>
     *     <li>初始化 elementUtils、typeUtils、filer、message 等工具类</li>
     *     <li>获取 {@code RouterInterceptor} 接口的类型镜像，供后续校验使用</li>
     *     <li>从配置参数中读取模块名称（{@code moduleName}）</li>
     *     <li>校验模块名称是否存在，若不存在则抛出异常并提示配置方法</li>
     *     <li>清理模块名称，过滤特殊字符，避免生成非法类名</li>
     * </ol>
     *
     * @param processingEnv 注解处理环境，提供各类工具类和配置信息
     */
    @Override
    public synchronized void init(ProcessingEnvironment processingEnv) {
        super.init(processingEnv);

        // 获取 RouterInterceptor 接口类型
        TypeElement interceptorElement = elementUtils.getTypeElement(CompilerConsts.ROUTER_INTERCEPTOR);
        if (interceptorElement != null) {
            routerInterceptorType = interceptorElement.asType();
        }

        printMessage(Diagnostic.Kind.NOTE, "Init InterceptorProcessor for module: " + moduleName);
    }

    /**
     * 处理注解的核心方法。
     * <p>
     * 在编译时每一轮处理中被调用，扫描带有 {@code @Interceptor} 注解的类元素，
     * 验证合法性并生成对应的拦截器管理类。
     * </p>
     *
     * <h3>处理流程：</h3>
     * <ol>
     *     <li>若为最后一轮处理（processingOver），直接返回 false</li>
     *     <li>获取所有被 {@code @Interceptor} 注解标记的 Element</li>
     *     <li>若无注解元素，输出提示日志并返回</li>
     *     <li>按 global 属性分组，分别生成模块拦截器和全局拦截器管理类</li>
     * </ol>
     *
     * <h3>返回值说明：</h3>
     * <ul>
     *     <li><b>true</b> - 注解已被处理，后续处理器不再处理此注解</li>
     *     <li><b>false</b> - 注解未被处理，后续处理器可以继续处理</li>
     * </ul>
     *
     * @param annotations 本轮处理中待处理的注解类型集合
     * @param roundEnv    本轮处理的环境信息，包含被注解的元素
     * @return 始终返回 true，表示 {@code @Interceptor} 注解已被处理
     */
    @Override
    public boolean process(Set<? extends TypeElement> annotations, RoundEnvironment roundEnv) {
        // 在最后一轮处理时跳过，避免重复生成
        if (roundEnv.processingOver()) {
            return false;
        }

        // 获取所有被 @Interceptor 注解的元素
        Set<? extends Element> interceptorElements = roundEnv.getElementsAnnotatedWith(Interceptor.class);

        if (interceptorElements.isEmpty()) {
            printMessage(Diagnostic.Kind.NOTE, "No @Interceptor annotations found in module: " + moduleName);
            return false;
        }

        printMessage(Diagnostic.Kind.NOTE, "Found " + interceptorElements.size() + " @Interceptor(s) in module: " + moduleName);

        try {
            // 按 global 属性分组
            Map<Boolean, List<Element>> grouped = new HashMap<>();
            for (Element element : interceptorElements) {
                Interceptor annotation = element.getAnnotation(Interceptor.class);
                if (annotation != null) {
                    boolean isGlobal = annotation.global();
                    grouped.computeIfAbsent(isGlobal, k -> new ArrayList<>()).add(element);
                }
            }

            // 生成模块拦截器类（global = false）
            List<Element> moduleInterceptors = grouped.getOrDefault(false, new ArrayList<>());
            if (!moduleInterceptors.isEmpty()) {
                generateInterceptorClass(moduleInterceptors,
                        CompilerConsts.ROUTER_INTERCEPTOR_PREFIX + moduleName);
            }

            // 生成全局拦截器类（global = true），使用模块名区分
            List<Element> globalInterceptors = grouped.getOrDefault(true, new ArrayList<>());
            if (!globalInterceptors.isEmpty()) {
                String globalClassName = CompilerConsts.ROUTER_INTERCEPTOR_GLOBAL_PREFIX + moduleName;
                generateInterceptorClass(globalInterceptors, globalClassName);
            }

        } catch (IOException e) {
            printMessage(Diagnostic.Kind.ERROR, "Failed to generate interceptor class: " + e.getMessage());
            return false;
        }

        return true;
    }

    // ==================== 代码生成方法 ====================

    /**
     * 生成拦截器管理类。
     * <p>
     * 使用 JavaPoet 库构建完整的 Java 类文件，包含：
     * <ul>
     *     <li>实现 {@code InterceptorModule} 接口</li>
     *     <li>私有字段 {@code Map<RouterInterceptor, Integer> priorityMap}</li>
     *     <li>构造函数，用于按优先级顺序初始化所有拦截器</li>
     *     <li>{@code getInterceptors} 方法，返回不可修改的拦截器列表</li>
     *     <li>{@code getPriorityMap} 方法，返回不可修改的优先级映射</li>
     * </ul>
     * </p>
     *
     * <h3>命名规则</h3>
     * <ul>
     *     <li>模块拦截器：{@link CompilerConsts#ROUTER_INTERCEPTOR_PREFIX} + 模块名</li>
     *     <li>全局拦截器：{@link CompilerConsts#ROUTER_INTERCEPTOR_GLOBAL_PREFIX} + 模块名</li>
     * </ul>
     *
     * @param interceptorElements 所有被 {@code @Interceptor} 注解标记的元素集合
     * @param className           生成的类名
     * @throws IOException 当文件写入失败时抛出
     */
    private void generateInterceptorClass(List<Element> interceptorElements,
                                          String className) throws IOException {
        // 验证并收集拦截器信息
        Set<Element> elementSet = new HashSet<>(interceptorElements);

        Map<Integer, List<InterceptorInfo>> interceptorMap = validateAndCollectInterceptors(elementSet);

        if (interceptorMap.isEmpty()) {
            printMessage(Diagnostic.Kind.WARNING, "No valid interceptors found, skip generation");
            return;
        }

        // InterceptorModule 接口
        ClassName interceptorModuleClass = ClassName.bestGuess(CompilerConsts.INTERCEPTOR_MODULE);

        // 构建类
        TypeSpec.Builder classBuilder = TypeSpec.classBuilder(className)
                .addModifiers(Modifier.PUBLIC, Modifier.FINAL)
                .addSuperinterface(interceptorModuleClass);

        // 添加优先级映射字段
        ClassName routerInterceptorClass = ClassName.bestGuess(CompilerConsts.ROUTER_INTERCEPTOR);
        ClassName integerClass = ClassName.get(Integer.class);
        ParameterizedTypeName mapType = ParameterizedTypeName.get(
                ClassName.get("java.util", "Map"),
                routerInterceptorClass,
                integerClass
        );
        classBuilder.addField(mapType, "priorityMap", Modifier.PRIVATE, Modifier.FINAL);

        // 添加构造函数
        MethodSpec constructor = createConstructor(interceptorMap);
        classBuilder.addMethod(constructor);

        // 添加 getInterceptors 方法
        MethodSpec getInterceptorsMethod = createGetInterceptors();
        classBuilder.addMethod(getInterceptorsMethod);

        // 添加 getPriorityMap 方法
        MethodSpec getPriorityMapMethod = createGetPriorityMap();
        classBuilder.addMethod(getPriorityMapMethod);


        // 生成 Java 文件
        JavaFile javaFile = JavaFile.builder(  CompilerConsts.INTERCEPTOR_PACKAGE, classBuilder.build())
                .addFileComment(formatComment(className, interceptorElements.size()))
                .skipJavaLangImports(true)
                .build();

        javaFile.writeTo(filer);

        printMessage(Diagnostic.Kind.NOTE, "✓ Generated: " +   CompilerConsts.INTERCEPTOR_PACKAGE + "." + className);
    }

    // ==================== 验证与收集方法 ====================

    /**
     * 验证并收集拦截器信息。
     * <p>
     * 遍历所有被 {@code @Interceptor} 注解标记的元素，执行多项校验，
     * 并将通过校验的拦截器按优先级排序后返回。
     * </p>
     *
     * <h3>校验规则：</h3>
     * <ol>
     *     <li><b>类型校验</b>：注解只能用于类，不能用于接口、枚举、方法等</li>
     *     <li><b>抽象类校验</b>：拦截器类必须可实例化</li>
     *     <li><b>接口实现校验</b>：必须实现 {@code RouterInterceptor} 接口</li>
     *     <li><b>优先级范围校验</b>：建议优先级在 [0, 100] 范围内，超出范围只警告不报错</li>
     * </ol>
     *
     * @param elements 所有被 {@code @Interceptor} 注解标记的元素集合
     * @return 按优先级排序的拦截器信息 Map（key 为优先级，value 为拦截器列表）
     */
    private Map<Integer, List<InterceptorInfo>> validateAndCollectInterceptors(Set<? extends Element> elements) {
        // 使用 TreeMap 自动按优先级排序（升序，优先级小的在前）
        Map<Integer, List<InterceptorInfo>> interceptorMap = new TreeMap<>();

        for (Element element : elements) {
            // ===== 校验1：必须是类 =====
            if (!element.getKind().isClass()) {
                error(element, "@Interceptor can only be applied to classes, not to %s", element.getKind());
                continue;
            }

            TypeElement typeElement = (TypeElement) element;
            String className = typeElement.getSimpleName().toString();

            // ===== 校验2：是否为抽象类 =====
            if (typeElement.getModifiers().contains(Modifier.ABSTRACT)) {
                error(element, "Interceptor class %s cannot be abstract", className);
                continue;
            }

            // ===== 校验3：必须实现 RouterInterceptor 接口 =====
            if (!implementsRouterInterceptor(typeElement)) {
                error(element, "%s must implement %s interface", className, CompilerConsts.ROUTER_INTERCEPTOR);
                continue;
            }

            // 获取优先级
            Interceptor annotation = element.getAnnotation(Interceptor.class);
            assert annotation != null;
            int priority = annotation.priority();

            // ===== 校验4：优先级负数检查（警告，不阻断） =====
            if (priority < 0) {
                printMessage(Diagnostic.Kind.WARNING, element,
                        "Priority %d is negative, which may cause unexpected behavior", priority);
            }

            // 获取拦截器完整类名
            String packageName = elementUtils.getPackageOf(element).getQualifiedName().toString();
            String fullClassName = packageName + "." + className;

            // 添加到对应优先级的列表中（可能出现相同优先级情况，需要按顺序处理）
            interceptorMap.computeIfAbsent(priority, k -> new ArrayList<>())
                    .add(new InterceptorInfo(fullClassName, priority));

            printMessage(Diagnostic.Kind.NOTE, "  ✓ Registered interceptor: %s (priority=%d)", className, priority);
        }

        return interceptorMap;
    }

    /**
     * 检查指定的类型元素是否实现了 RouterInterceptor 接口
     * <p>
     * 包括直接实现和通过父类继承实现。
     * </p>
     */
    private boolean implementsRouterInterceptor(TypeElement typeElement) {
        if (routerInterceptorType == null) {
            return true;
        }

        // 1. 检查直接实现的接口
        for (TypeMirror interfaceType : typeElement.getInterfaces()) {
            if (typeUtils.isSameType(interfaceType, routerInterceptorType)) {
                return true;
            }
        }

        // 2. 检查父类是否实现了接口
        TypeMirror superclass = typeElement.getSuperclass();
        if (!superclass.toString().equals("java.lang.Object")) {
            TypeElement superElement = (TypeElement) typeUtils.asElement(superclass);
            return implementsRouterInterceptor(superElement);
        }

        return false;
    }

    // ==================== 方法构建方法 ====================

    /**
     * 创建构造函数，用于初始化拦截器优先级映射。
     * <p>
     * 构造函数内部会：
     * <ol>
     *     <li>创建 LinkedHashMap 实例（保持插入顺序）</li>
     *     <li>按优先级升序遍历所有拦截器</li>
     *     <li>依次实例化拦截器并放入映射中</li>
     * </ol>
     * </p>
     *
     * <h3>生成代码示例：</h3>
     * <pre>{@code
     * public Router$$Interceptor$$circlemodule() {
     *     priorityMap = new LinkedHashMap<>();
     *     // Priority: 10
     *     priorityMap.put(new LoginInterceptor(), 10);
     *     // Priority: 20
     *     priorityMap.put(new PermissionInterceptor(), 20);
     * }
     * }</pre>
     *
     * @param interceptorMap 按优先级排序的拦截器信息 Map
     * @return 构造函数的方法定义
     */
    private MethodSpec createConstructor(Map<Integer, List<InterceptorInfo>> interceptorMap) {
        MethodSpec.Builder constructorBuilder = MethodSpec.constructorBuilder()
                .addModifiers(Modifier.PUBLIC);

        // 初始化 LinkedHashMap（保持插入顺序）
        constructorBuilder.addStatement("priorityMap = new $T<>()",
                ClassName.get("java.util", "LinkedHashMap"));

        // 按优先级顺序添加拦截器
        for (Map.Entry<Integer, List<InterceptorInfo>> entry : interceptorMap.entrySet()) {
            int priority = entry.getKey();
            List<InterceptorInfo> interceptorList = entry.getValue();

            constructorBuilder.addCode("\n");
            constructorBuilder.addCode("// Priority: " + priority + "\n");

            for (InterceptorInfo info : interceptorList) {
                ClassName interceptorClass = ClassName.bestGuess(info.fullClassName());
                constructorBuilder.addStatement(
                        "priorityMap.put(new $T(), $L)",
                        interceptorClass,
                        priority
                );
            }
        }

        return constructorBuilder.build();
    }

    /**
     * 创建 {@code getInterceptors} 方法。
     * <p>
     * 该方法实现了 {@code InterceptorModule} 接口的抽象方法，
     * 返回当前模块的所有拦截器列表（按优先级排序）。
     * </p>
     *
     * <h3>线程安全设计</h3>
     * 使用 {@link java.util.Collections#unmodifiableList} 包装返回列表，
     * 防止外部修改拦截器列表，保证线程安全。
     *
     * <h3>生成代码示例：</h3>
     * <pre>{@code
     * @Override
     * public final List<RouterInterceptor> getInterceptors() {
     *     return Collections.unmodifiableList(new ArrayList<>(priorityMap.keySet()));
     * }
     * }</pre>
     *
     * @return getInterceptors 方法的方法定义
     */
    private MethodSpec createGetInterceptors() {
        ClassName listClass = ClassName.get(List.class);
        ClassName arrayListClass = ClassName.get(ArrayList.class);
        ClassName routerInterceptorClass = ClassName.bestGuess(CompilerConsts.ROUTER_INTERCEPTOR);
        ParameterizedTypeName returnType = ParameterizedTypeName.get(listClass, routerInterceptorClass);

        ClassName collectionsClass = ClassName.get("java.util", "Collections");

        return MethodSpec.methodBuilder("getInterceptors")
                .addAnnotation(Override.class)
                .addModifiers(Modifier.PUBLIC)
                .returns(returnType)
                .addComment("从 priorityMap 的 keySet 创建不可修改的拦截器列表")
                .addStatement("return $T.unmodifiableList(new $T<>(priorityMap.keySet()))",
                        collectionsClass, arrayListClass)
                .build();
    }

    /**
     * 创建 {@code getPriorityMap} 方法
     * <p>
     * 该方法返回拦截器实例与优先级的映射关系，用于运行时跨模块合并时按优先级排序。
     * </p>
     *
     * <h3>生成代码示例：</h3>
     * <pre>{@code
     * @Override
     * public Map<RouterInterceptor, Integer> getPriorityMap() {
     *     return Collections.unmodifiableMap(priorityMap);
     * }
     * }</pre>
     *
     * <h3>设计说明</h3>
     * <ul>
     *     <li>返回不可修改的 Map，防止外部篡改优先级信息</li>
     *     <li>Key 为拦截器实例，Value 为注解中定义的优先级值</li>
     *     <li>运行时通过此方法获取所有拦截器的优先级，进行跨模块排序</li>
     * </ul>
     *
     * @return getPriorityMap 方法的方法定义
     */
    private MethodSpec createGetPriorityMap() {
        ClassName mapClass = ClassName.get("java.util", "Map");
        ClassName routerInterceptorClass = ClassName.bestGuess(CompilerConsts.ROUTER_INTERCEPTOR);
        ClassName integerClass = ClassName.get(Integer.class);
        ParameterizedTypeName returnType = ParameterizedTypeName.get(mapClass, routerInterceptorClass, integerClass);

        ClassName collectionsClass = ClassName.get("java.util", "Collections");

        return MethodSpec.methodBuilder("getPriorityMap")
                .addAnnotation(Override.class)
                .addModifiers(Modifier.PUBLIC)
                .returns(returnType)
                .addComment("返回不可修改的优先级映射")
                .addStatement("return $T.unmodifiableMap(priorityMap)", collectionsClass)
                .build();
    }

    // ==================== 元数据方法 ====================

    /**
     * 返回当前注解处理器需要处理的注解类型集合。
     * <p>
     * 此集合中的注解标记的元素才会传递给 {@link #process} 方法。
     * </p>
     *
     * @return 包含 {@link Interceptor} 注解全类名的集合
     */
    @Override
    public Set<String> getSupportedAnnotationTypes() {
        Set<String> types = new LinkedHashSet<>();
        types.add(Interceptor.class.getCanonicalName());
        return types;
    }

    // ==================== 内部类 ====================

    /**
     * 拦截器信息内部类。
     * <p>
     * 用于临时存储拦截器的完整类名和优先级信息，
     * 在验证阶段收集数据，在代码生成阶段使用。
     * </p>
     *
     * @param fullClassName 拦截器的完整类名（包含包名）
     * @param priority      拦截器优先级，数值越小优先级越高
     */
    private record InterceptorInfo(String fullClassName, int priority) {
        /**
         * 构造拦截器信息对象。
         *
         * @param fullClassName 拦截器完整类名
         * @param priority      拦截器优先级
         */
        private InterceptorInfo {
        }
    }
}