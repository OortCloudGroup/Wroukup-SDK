package com.router.compiler;

import com.router.base.annotation.Route;
import com.router.base.ThreadMode;
import com.google.auto.service.AutoService;
import com.squareup.javapoet.ClassName;
import com.squareup.javapoet.JavaFile;
import com.squareup.javapoet.MethodSpec;
import com.squareup.javapoet.ParameterizedTypeName;
import com.squareup.javapoet.TypeSpec;

import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import javax.annotation.processing.ProcessingEnvironment;
import javax.annotation.processing.Processor;
import javax.annotation.processing.RoundEnvironment;
import javax.lang.model.element.Element;
import javax.lang.model.element.Modifier;
import javax.lang.model.element.TypeElement;
import javax.lang.model.type.TypeMirror;
import javax.tools.Diagnostic;

/**
 * {@link Route} 注解处理器。
 * <p>
 * 在编译时扫描所有被 {@code @Route} 注解标记的类，验证其合法性，并为每个模块自动生成
 * 对应的路由注册类 {@code Router$$Module$$xxx}，该类实现了 {@code RouterModule} 接口。
 * </p>
 *
 * <h3>生成类命名规则</h3>
 * <pre>
 * 模块名示例：circle
 * 生成类名：Router$$Module$$circle
 * 包名：com.router.modules
 * </pre>
 *
 * <h3>支持的注解类型</h3>
 * <ul>
 *     <li>实现了 {@code RouterHandler} 接口的处理器类</li>
 *     <li>Activity 类（自动包装为 Activity 跳转处理器）</li>
 * </ul>
 *
 * <h3>配置要求</h3>
 * 使用此处理器时，必须通过 {@code annotationProcessorOptions} 配置模块名称：
 * <pre>{@code
 * android {
 *     defaultConfig {
 *         javaCompileOptions {
 *             annotationProcessorOptions {
 *                 arguments = [moduleName: project.getName()]
 *             }
 *         }
 *     }
 * }
 * }</pre>
 *
 * @author Zhang zhijun on 2026/5/13 9:39
 * @version 1.0
 * @see Route
 * @since 1.0.0
 */
@AutoService(Processor.class)
public class RouterModuleProcessor extends BaseProcessor {

    /**
     * RouterHandler 接口的类型镜像，用于类型校验
     * com.router.api.router.RouterHandler
     */
    private TypeMirror routerHandlerType;

    // ==================== 生命周期方法 ====================

    /**
     * 初始化注解处理器。
     * <p>
     * 在处理器实例化后调用，用于初始化编译环境工具类、获取配置参数、校验必要配置。
     * </p>
     *
     * <h3>执行步骤：</h3>
     * <ol>
     *     <li>初始化 elementUtils、typeUtils、filer、message 等工具类</li>
     *     <li>获取 {@code RouterHandler} 接口的类型镜像，供后续校验使用</li>
     *     <li>从配置参数中读取模块名称（{@code moduleName}）</li>
     *     <li>校验模块名称是否存在，若不存在则抛出异常并提示配置方法</li>
     *     <li>清理模块名称，过滤特殊字符</li>
     * </ol>
     *
     * @param processingEnv 注解处理环境，提供各类工具类和配置信息
     */
    @Override
    public synchronized void init(ProcessingEnvironment processingEnv) {
        super.init(processingEnv);

        // 获取 RouterHandler 接口类型
        TypeElement routerHandlerElement = elementUtils.getTypeElement(CompilerConsts.ROUTE_HANDLER);
        if (routerHandlerElement != null) {
            routerHandlerType = routerHandlerElement.asType();
        }

        printMessage(Diagnostic.Kind.NOTE, "Init ModuleProcessor for module: " + moduleName);
    }

    /**
     * 处理注解的核心方法。
     * <p>
     * 在编译时每一轮处理中被调用，扫描带有 {@code @Route} 注解的类元素，
     * 验证合法性并生成对应的路由注册类。
     * </p>
     *
     * <h3>处理流程：</h3>
     * <ol>
     *     <li>若为最后一轮处理（processingOver），直接返回 false</li>
     *     <li>获取所有被 {@code @Route} 注解标记的 Element</li>
     *     <li>若无注解元素，输出提示日志并返回</li>
     *     <li>调用 {@link #generateModuleClass(Set)} 生成模块类</li>
     * </ol>
     *
     * <h3>返回值说明：</h3>
     * <ul>
     *     <li><b>true</b> - 注解已被处理，后续处理器不再处理此注解</li>
     *     <li><b>false</b> - 注解未被处理，后续处理器可以继续处理</li>
     * </ul>
     *
     * @param annotations 本轮处理中待处理的注解类型集合
     * @param roundEnv    本轮处理的环境信息，包含被注解的元素
     * @return 始终返回 true，表示 {@code @Route} 注解已被处理
     */
    @Override
    public boolean process(Set<? extends TypeElement> annotations, RoundEnvironment roundEnv) {
        // 在最后一轮处理时跳过，避免重复生成
        if (roundEnv.processingOver()) {
            return false;
        }

        // 获取所有被 @Route 注解的元素
        Set<? extends Element> routeElements = roundEnv.getElementsAnnotatedWith(Route.class);

        if (routeElements.isEmpty()) {
            printMessage(Diagnostic.Kind.NOTE, "No @Route annotations found in module: " + moduleName);
            return false;
        }

        printMessage(Diagnostic.Kind.NOTE, "Found " + routeElements.size() + " @Route(s) in module: " + moduleName);

        try {
            generateModuleClass(routeElements);
        } catch (IOException e) {
            printMessage(Diagnostic.Kind.ERROR, "Failed to generate module class: " + e.getMessage());
            return false;
        }

        return false;
    }

    // ==================== 代码生成方法 ====================

    /**
     * 生成模块路由注册类。
     * <p>
     * 使用 JavaPoet 库构建完整的 Java 类文件，包含：
     * <ul>
     *     <li>实现 {@code RouterModule} 接口</li>
     *     <li>私有字段 {@code Map<String, RouterWrapper> handlers}</li>
     *     <li>构造函数，用于注册所有路由处理器</li>
     *     <li>{@code findHandler} 方法，根据路径查找处理器</li>
     * </ul>
     * </p>
     *
     * <h3>命名规则</h3>
     * 生成类名 = {@link CompilerConsts#ROUTER_MODULE_PREFIX} + 模块名
     * <br>
     * 示例：模块名 circle→ Router$$Module$$circle
     *
     * @param routeElements 所有被 {@code @Route} 注解标记的元素集合
     * @throws IOException 当文件写入失败时抛出
     */
    private void generateModuleClass(Set<? extends Element> routeElements) throws IOException {
        // 类名
        String className = CompilerConsts.ROUTER_MODULE_PREFIX + moduleName;

        // RouterModule 接口
        ClassName routerModuleClass = ClassName.bestGuess(CompilerConsts.ROUTE_MODULE);

        // Map 类型: Map<String, RouterWrapper>
        ClassName mapClass = ClassName.get("java.util", "Map");
        // RouterWrapper 类型
        ClassName routerWrapperClass = ClassName.bestGuess(CompilerConsts.ROUTE_WRAPPER);
        // Map<String, RouterWrapper> 参数化类型
        ParameterizedTypeName mapType = ParameterizedTypeName.get(mapClass,
                ClassName.get(String.class), routerWrapperClass);

        // 构建类
        TypeSpec.Builder classBuilder = TypeSpec.classBuilder(className)
                .addModifiers(Modifier.PUBLIC, Modifier.FINAL)
                .addSuperinterface(routerModuleClass)
                .addField(mapType, "handlers", Modifier.PRIVATE, Modifier.FINAL);

        // 构建构造函数
        MethodSpec constructor = createConstructor(routeElements);
        classBuilder.addMethod(constructor);

        // 构建 findHandler 方法
        MethodSpec findHandlerMethod = createFindHandlerMethod();
        classBuilder.addMethod(findHandlerMethod);

        // 生成 Java 文件
        JavaFile javaFile = JavaFile.builder(CompilerConsts.MODULE_PACKAGE, classBuilder.build())
                .addFileComment(formatComment(className, routeElements.size()))
                .build();

        javaFile.writeTo(filer);

        printMessage(Diagnostic.Kind.NOTE, "✓ Generated: " + CompilerConsts.MODULE_PACKAGE + "." + className);
    }

    /**
     * 创建构造函数，用于初始化 {@code handlers} Map 并注册所有路由处理器。
     *
     * <h3>注册流程</h3>
     * <ol>
     *     <li>初始化 {@code HashMap} 实例</li>
     *     <li>遍历每个 {@code @Route} 注解元素：</li>
     *     <li>提取 {@code path}、{@code extraProcess}、{@code threadMode} 属性</li>
     *     <li>校验路径格式是否以 {@code 模块名/} 开头</li>
     *     <li>获取类的完整类名</li>
     *     <li>判断是 Activity 还是 RouterHandler</li>
     *     <li>Activity → 注册 ActivityStarterHandler(Activity.class)</li>
     *     <li>RouterHandler → 检查是否实现接口</li>
     *     <li>检查路径是否重复注册</li>
     *     <li>调用 {@code RouterWrapper.build()} 创建包装对象并放入 Map</li>
     * </ol>
     *
     * @param routeElements 所有被 {@code @Route} 注解标记的元素集合
     * @return 构造函数的方法定义
     */
    private MethodSpec createConstructor(Set<? extends Element> routeElements) {
        MethodSpec.Builder constructorBuilder = MethodSpec.constructorBuilder()
                .addModifiers(Modifier.PUBLIC);

        // 初始化 HashMap
        ClassName hashMapClass = ClassName.get("java.util", "HashMap");
        constructorBuilder.addStatement("handlers = new $T<>()", hashMapClass);

        // RouterWrapper 路由包装类
        ClassName routeWrapperClass = ClassName.bestGuess(CompilerConsts.ROUTE_WRAPPER);
        // ThreadMode 线程模式
        ClassName threadModeClass = ClassName.bestGuess(CompilerConsts.THREAD_MODE);
        // ActivityProxy 路由代理类
        ClassName activityProxyClass = ClassName.bestGuess(CompilerConsts.ACTIVITY_PROXY_ROUTE);
        // ServiceProxy 路由代理类
        ClassName serviceProxyClass = ClassName.bestGuess(CompilerConsts.SERVICE_PROXY_ROUTE);

        // 用于检测路径重复的临时 Map
        Map<String, String> registeredHandlers = new HashMap<>();

        for (Element element : routeElements) {
            // 获取注解信息
            Route annotation = element.getAnnotation(Route.class);
            assert annotation != null;
            String routePath = annotation.path();
            boolean extraProcess = annotation.extraProcess();
            ThreadMode threadMode = annotation.threadMode();

            // ===== 校验1：路径必须以模块名开头 =====
            String expectedPrefix = moduleName + "/";
            if (!routePath.startsWith(expectedPrefix)) {
                error(element, "Route path '%s' must start with '%s'", routePath, expectedPrefix);
                continue;
            }

            // 获取类的完整名称
            String packageName = elementUtils.getPackageOf(element).getQualifiedName().toString();
            String className = element.getSimpleName().toString();
            String fullClassName = packageName + "." + className;
            ClassName targetClass = ClassName.bestGuess(fullClassName);

            // 判断是否是Activity
            boolean isActivity = isActivity(element);
            // 判断是否是Service
            boolean isService = isService(element);

            // ===== 校验2：非代理，必须实现 RouteHandler 接口 =====
            if (!isActivity && !isService) {
                if (element instanceof TypeElement typeElement) {
                    boolean implementsInterface = false;
                    for (TypeMirror interfaceType : typeElement.getInterfaces()) {
                        if (typeUtils.isSameType(interfaceType, routerHandlerType)) {
                            implementsInterface = true;
                            break;
                        }
                    }
                    if (!implementsInterface) {
                        error(element, "%s must implement %s", element.getSimpleName(), CompilerConsts.ROUTE_HANDLER);
                        continue;
                    }
                }
            }

            // ===== 校验3：路径不能重复注册 =====
            if (registeredHandlers.containsKey(routePath)) {
                error(element, "Route path '%s' already exists (registered by %s)",
                        routePath, registeredHandlers.get(routePath));
                continue;
            }
            registeredHandlers.put(routePath, fullClassName);

            // ===== 注册路由处理器 =====
            constructorBuilder.addCode("\n");
            constructorBuilder.addCode("// Register: " + routePath + "\n");

            // 确定代理类：Activity → ActivityProxyRoute，Service → ServiceProxyRoute，其他 → null
            ClassName proxyClass = isActivity ? activityProxyClass
                    : isService ? serviceProxyClass
                      : null;

            if (proxyClass != null) {
                // 代理类型：通过代理类包装注册
                constructorBuilder.addStatement(
                        "handlers.put($S, $T.fromInstance(new $T($T.class), $S, $T.$L, $L))",
                        routePath,
                        routeWrapperClass,
                        proxyClass,
                        targetClass,
                        routePath,
                        threadModeClass,
                        threadMode.name(),
                        extraProcess
                );
            } else {
                // RouterHandler：直接注册
                constructorBuilder.addStatement(
                        "handlers.put($S, $T.fromClass($T.class, $S, $T.$L, $L))",
                        routePath,
                        routeWrapperClass,
                        targetClass,
                        routePath,
                        threadModeClass,
                        threadMode.name(),
                        extraProcess
                );
            }
        }

        return constructorBuilder.build();
    }

    /**
     * 判断一个 Element 是否是 Activity 或其子类。
     *
     * @param element 待判断的元素
     * @return 如果是 Activity 返回 true，否则返回 false
     */
    private boolean isActivity(Element element) {
        return isSubclassOf(element, "android.app.Activity");
    }

    /**
     * 判断一个 Element 是否是 Service 或其子类。
     *
     * @param element 待判断的元素
     * @return 如果是 Service 返回 true，否则返回 false
     */
    private boolean isService(Element element) {
        return isSubclassOf(element, "android.app.Service");
    }

    /**
     * 判断一个 Element 是否是某个类的子类。
     *
     * @param element       待判断的元素
     * @param qualifiedName 父类的全限定名
     * @return 如果是子类返回 true，否则返回 false
     */
    private boolean isSubclassOf(Element element, String qualifiedName) {
        if (!(element instanceof TypeElement typeElement)) {
            return false;
        }

        TypeElement targetElement = elementUtils.getTypeElement(qualifiedName);
        if (targetElement == null) {
            return false;
        }
        // 从元素自身开始沿继承链向上查找，使用全限定名比较避免 isSameType 在不同 TypeMirror 来源下比较失败
        TypeMirror current = typeElement.asType();
        while (current != null) {
            TypeElement currentElement = (TypeElement) typeUtils.asElement(current);
            if (currentElement == null) {
                break;
            }
            if (currentElement.getQualifiedName().contentEquals(qualifiedName)) {
                return true;
            }
            current = currentElement.getSuperclass();
        }

        return false;
    }

    /**
     * 创建 {@code findHandler} 方法。
     * <p>
     * 该方法实现了 {@code RouterModule} 接口的抽象方法，
     * 根据传入的路由路径从 {@code handlers} Map 中查找对应的 {@code RouterWrapper}。
     * </p>
     *
     * <h3>生成代码示例：</h3>
     * <pre>{@code
     * @Override
     * public final RouterWrapper findHandler(String path) {
     *     return handlers.get(path);
     * }
     * }</pre>
     *
     * @return findHandler 方法的方法定义
     */
    private MethodSpec createFindHandlerMethod() {
        ClassName routerWrapperClass = ClassName.bestGuess(CompilerConsts.ROUTE_WRAPPER);

        return MethodSpec.methodBuilder("findRouteWrapper")
                .addAnnotation(Override.class)
                .addModifiers(Modifier.PUBLIC, Modifier.FINAL)
                .returns(routerWrapperClass)
                .addParameter(String.class, "path")
                .addComment("根据路由路径查找并返回对应的 RouterWrapper")
                .addStatement("return handlers.get(path)")
                .build();
    }

    // ==================== 元数据方法 ====================

    /**
     * 返回当前注解处理器需要处理的注解类型集合。
     * <p>
     * 此集合中注解标记的元素才会传递给 {@link #process} 方法。
     * </p>
     *
     * @return 包含 {@link Route} 注解全类名的集合
     */
    @Override
    public Set<String> getSupportedAnnotationTypes() {
        Set<String> types = new LinkedHashSet<>();
        types.add(Route.class.getCanonicalName());
        return types;
    }
}