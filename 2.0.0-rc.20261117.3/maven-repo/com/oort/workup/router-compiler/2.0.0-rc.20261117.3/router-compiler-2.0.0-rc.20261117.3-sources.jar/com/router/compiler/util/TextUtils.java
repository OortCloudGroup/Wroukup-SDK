package com.router.compiler.util;


/**
 * description: 字符串工具类 判断模块名是否为空
 * @author Zhang zhijun on 2026/5/13
 * @version 1.0
 * @since 1.0.0
 */
public class TextUtils {
    public static boolean isEmpty(String moduleName) {
        return moduleName == null || moduleName.isEmpty();
    }
}
