#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
NDK=/Users/lichao/Library/Android/sdk/ndk/27.1.12297006
CMAKE=/Users/lichao/Library/Android/sdk/cmake/3.22.1/bin/cmake
NINJA=/Users/lichao/Library/Android/sdk/cmake/3.22.1/bin/ninja
SOURCE="$ROOT/official-source/rtmp-client"
mkdir -p "$ROOT/evidence"
for ABI in arm64-v8a x86_64; do
  "$CMAKE" -S "$SOURCE" -B "$ROOT/build/$ABI" -G Ninja \
    "-DCMAKE_MAKE_PROGRAM=$NINJA" \
    "-DCMAKE_TOOLCHAIN_FILE=$NDK/build/cmake/android.toolchain.cmake" \
    "-DANDROID_NDK=$NDK" "-DANDROID_ABI=$ABI" \
    -DANDROID_PLATFORM=android-21 -DANDROID_SUPPORT_FLEXIBLE_PAGE_SIZES=ON \
    -DCMAKE_BUILD_TYPE=Release -DCMAKE_EXPORT_COMPILE_COMMANDS=ON \
    -DCMAKE_SHARED_LINKER_FLAGS=-Wl,-z,max-page-size=16384 \
    2>&1 | tee "$ROOT/evidence/configure-$ABI.log"
  "$CMAKE" --build "$ROOT/build/$ABI" --target rtmp-jni --parallel 4 --verbose \
    2>&1 | tee "$ROOT/evidence/build-$ABI.log"
done
