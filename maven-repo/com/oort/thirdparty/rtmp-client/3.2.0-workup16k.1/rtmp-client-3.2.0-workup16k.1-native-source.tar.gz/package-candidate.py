from pathlib import Path
import hashlib
import json
import re
import shutil
import struct
import subprocess
import tarfile
import zipfile

ROOT = Path(__file__).resolve().parent
SRC = ROOT / 'official-source'
BASE = ROOT / 'baseline/aar'
STAGE = ROOT / 'candidate-aar'
EVIDENCE = ROOT / 'evidence'
BIN = Path('/Users/lichao/Library/Android/sdk/ndk/27.1.12297006/toolchains/llvm/prebuilt/darwin-x86_64/bin')
VERSION = '3.2.0-workup16k.1'
STEM = 'rtmp-client-' + VERSION
REPO = ROOT / 'maven-repo'
DEST = REPO / 'com/oort/thirdparty/rtmp-client' / VERSION
COORD = 'com.oort.thirdparty:rtmp-client:' + VERSION
DEST.mkdir(parents=True, exist_ok=True)

def sha(path, algo='sha256'):
    return hashlib.new(algo, path.read_bytes()).hexdigest()

def run(*args):
    return subprocess.check_output([str(a) for a in args], text=True)

def zip_files(path, files):
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, data in sorted(files.items()):
            info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            z.writestr(info, data)

# Copy every original AAR entry, replacing exactly two native library entries.
with zipfile.ZipFile(ROOT / 'baseline/rtmp-client-3.2.0.aar') as z:
    original = {n: z.read(n) for n in z.namelist()}
entries = dict(original)
checks = {}
for abi in ('arm64-v8a', 'x86_64'):
    stage = STAGE / 'jni' / abi / 'librtmp-jni.so'
    stage.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(ROOT / 'build' / abi / 'librtmp-jni.so', stage)
    subprocess.run([str(BIN / 'llvm-strip'), '--strip-unneeded', str(stage)], check=True)
    entries['jni/' + abi + '/librtmp-jni.so'] = stage.read_bytes()
    before = BASE / 'jni' / abi / 'librtmp-jni.so'
    def symbols(p):
        return {l.split()[-1]: l.split()[-2] for l in run(BIN / 'llvm-nm', '-D', '--defined-only', p).splitlines() if l.strip()}
    oldsym, newsym = symbols(before), symbols(stage)
    oldjni = sorted(n for n in oldsym if n.startswith('Java_'))
    newjni = sorted(n for n in newsym if n.startswith('Java_'))
    assert oldjni == newjni and len(newjni) == 17
    missing = {n: oldsym[n] for n in oldsym.keys() - newsym.keys()}
    assert all(v == 'A' for v in missing.values()), missing
    data = stage.read_bytes()
    assert data[:6] == b'\x7fELF\x02\x01'
    phoff = struct.unpack_from('<Q', data, 32)[0]
    phentsize, phnum = struct.unpack_from('<HH', data, 54)
    loads = []
    for i in range(phnum):
        ptype, flags, offset, vaddr, paddr, filesz, memsz, align = struct.unpack_from('<IIQQQQQQ', data, phoff + i * phentsize)
        if ptype == 1:
            assert align == 16384 and (vaddr - offset) % 16384 == 0
            loads.append({'offset': offset, 'vaddr': vaddr, 'filesz': filesz, 'memsz': memsz, 'align': align})
    assert loads
    old_dynamic = run(BIN / 'llvm-readelf', '-dW', before)
    new_dynamic = run(BIN / 'llvm-readelf', '-dW', stage)
    needed = lambda s: re.findall(r'\(NEEDED\).*?\[(.*?)\]', s)
    assert needed(old_dynamic) == needed(new_dynamic)
    assert 'Library soname: [librtmp-jni.so]' in new_dynamic
    for kind, p in [('original', before), ('candidate', stage)]:
        (EVIDENCE / (kind + '-' + abi + '-readelf.txt')).write_text(run(BIN / 'llvm-readelf', '-hlWdVs', p))
        (EVIDENCE / (kind + '-' + abi + '-exports.txt')).write_text(run(BIN / 'llvm-nm', '-D', '--defined-only', p))
    checks[abi] = {'jni_count': len(newjni), 'jni_equal': True, 'jni_exports': newjni,
                   'all_function_and_object_exports_retained': True,
                   'removed_linker_absolute_symbols': sorted(missing), 'load_segments': loads,
                   'all_load_alignments_16k_and_congruent': True,
                   'soname': 'librtmp-jni.so', 'dt_needed': needed(new_dynamic),
                   'original_sha256': sha(before), 'candidate_sha256': sha(stage),
                   'candidate_size': stage.stat().st_size}

changed_entries = sorted(n for n in entries if entries[n] != original[n])
assert changed_entries == ['jni/arm64-v8a/librtmp-jni.so', 'jni/x86_64/librtmp-jni.so']
AAR = DEST / (STEM + '.aar')
zip_files(AAR, entries)
shutil.copy2(AAR, ROOT / AAR.name)
# Java/API and both 32-bit native libraries remain byte-for-byte identical.
assert entries['classes.jar'] == original['classes.jar']
for abi in ('armeabi-v7a', 'x86'):
    assert entries['jni/' + abi + '/librtmp-jni.so'] == original['jni/' + abi + '/librtmp-jni.so']

licenses = {
    'LICENSE-Apache-2.0': (SRC / 'LICENSE').read_bytes(),
    'COPYING-librtmp-LGPL-2.1': (SRC / 'rtmp-client/src/main/cpp/librtmp/COPYING').read_bytes(),
    'librtmp-source-license-notice.txt': (SRC / 'rtmp-client/src/main/cpp/librtmp/rtmp.c').read_text().split('#include', 1)[0].encode(),
}
zip_files(DEST / (STEM + '-licenses.zip'), licenses)
for name, data in licenses.items():
    (ROOT / 'licenses').mkdir(exist_ok=True)
    (ROOT / 'licenses' / name).write_bytes(data)
POM = DEST / (STEM + '.pom')
POM.write_text('''<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
  <modelVersion>4.0.0</modelVersion>
  <groupId>com.oort.thirdparty</groupId>
  <artifactId>rtmp-client</artifactId>
  <version>3.2.0-workup16k.1</version>
  <packaging>aar</packaging>
  <name>RTMP Client for Android - local 16KB candidate</name>
  <description>Original io.antmedia 3.2.0 Java and 32-bit native payloads; arm64-v8a and x86_64 rebuilt from official Ant Media source for 16KB pages.</description>
  <url>https://github.com/ant-media/LibRtmp-Client-for-Android</url>
  <licenses>
    <license><name>Apache License 2.0 (top-level)</name><url>https://www.apache.org/licenses/LICENSE-2.0.txt</url></license>
    <license><name>LGPL 2.1 or later (bundled librtmp)</name><url>https://www.gnu.org/licenses/old-licenses/lgpl-2.1.html</url></license>
  </licenses>
  <scm><url>https://github.com/ant-media/LibRtmp-Client-for-Android</url><tag>3af67842f517f9c6bbd22b961878624d0c44b713</tag></scm>
  <dependencies/>
</project>
''')
# Official Java sources; native source and reproducible build recipe attached separately.
shutil.copy2(ROOT / 'baseline/rtmp-client-3.2.0-sources.jar', DEST / (STEM + '-sources.jar'))
patch = run('git', '-C', SRC, 'diff', '--', 'rtmp-client/src/main/cpp/flvmuxer/xiecc_rtmp.c')
(ROOT / 'string-header.patch').write_text(patch)
(EVIDENCE / 'java-jni-descriptors.txt').write_text(run('/Library/Java/JavaVirtualMachines/temurin-21.jdk/Contents/Home/bin/javap', '-s', '-p', '-classpath', BASE / 'classes.jar', 'io.antmedia.rtmp_client.RtmpClient', 'io.antmedia.rtmp_client.RTMPMuxer'))
# Source and dependency evidence: source contains all native implementation and uses NO_CRYPTO.
subprocess.run(['git', '-C', str(SRC), 'diff', '--exit-code', 'b853f185640ab75b840871ed088e117cf397dfa2', 'HEAD', '--', 'rtmp-client/src/main/cpp'], check=True)
with zipfile.ZipFile(ROOT / 'baseline/rtmp-client-3.2.0-sources.jar') as z:
    for n in z.namelist():
        if n.endswith('.java'):
            assert z.read(n) == (SRC / 'rtmp-client/src/main/java' / n).read_bytes()
manifest = {
    'coordinate': COORD, 'maven_repository': str(REPO), 'aar': str(AAR), 'aar_sha256': sha(AAR),
    'original_coordinate': 'io.antmedia:rtmp-client:3.2.0',
    'original_aar_sha256': sha(ROOT / 'baseline/rtmp-client-3.2.0.aar'),
    'original_central_sha1': '56ffc6f4fa0ab38969527e20becb6d6ca3b221e4',
    'original_central_sha1_url': 'https://repo.maven.apache.org/maven2/io/antmedia/rtmp-client/3.2.0/rtmp-client-3.2.0.aar.sha1',
    'source_url': 'https://github.com/ant-media/LibRtmp-Client-for-Android.git',
    'source_commit': '3af67842f517f9c6bbd22b961878624d0c44b713',
    'source_archive_sha256': sha(ROOT / 'official-source-3af67842.tar.gz'),
    'official_tags': {'v3.1.0': 'c361f5da14d3bf7ed1affb4ea0ff41b53ba9d41c'},
    'v3_2_0_tag_exists': False,
    'release_version_commit': '6ab56766b9dd77e9a7ce78653f1988fcf2047004',
    'release_era_merge_commit': 'b853f185640ab75b840871ed088e117cf397dfa2',
    'native_source_matches_release_era_merge': True,
    'release_version_commit_vs_release_era_merge_difference': 'One blank line in flvmuxer/xiecc_rtmp.c only.',
    'java_sources_match_maven_sources_byte_for_byte': True,
    'source_local_patch': 'Added #include <string.h> to flvmuxer/xiecc_rtmp.c to declare memcpy under Clang 18; no API/JNI or logic edits.',
    'patch_sha256': sha(ROOT / 'string-header.patch'),
    'toolchain': {'ndk': '27.1.12297006 (r27b)', 'cmake': '3.22.1', 'ninja': '1.10.2', 'clang': '18.0.2', 'android_api': 21,
                  'flexible_page_sizes': True, 'link_flag': '-Wl,-z,max-page-size=16384', 'build_type': 'Release', 'no_crypto': True,
                  'ndk_source_properties_sha256': sha(Path('/Users/lichao/Library/Android/sdk/ndk/27.1.12297006/source.properties')),
                  'clang_sha256': sha(BIN / 'clang'), 'ld_lld_sha256': sha(BIN / 'ld.lld')},
    'changed_original_aar_entries': changed_entries, 'unchanged_entries_byte_for_byte': sorted(set(entries) - set(changed_entries)),
    'classes_jar_sha256': hashlib.sha256(entries['classes.jar']).hexdigest(),
    'elf_checks': checks,
    'licenses': ['Apache-2.0 (top-level)', 'LGPL-2.1-or-later (librtmp sources; COPYING supplies LGPL 2.1 text)'],
    'limitations': ['Local candidate only, not integrated into RC.', 'No device or RTMP stream runtime verification performed.',
                    '32-bit armeabi-v7a and x86 are retained byte-for-byte and were not rebuilt or certified for 16KB.',
                    'Upstream compiler warnings retained: pointer sign/const, float word order assumption, missing return in rtmp_close.',
                    'No other library was changed. wlt vendor library cannot be locally legally rebuilt; vendor replacement remains required.'],
    'integration': {'repository': str(REPO), 'dependency': "implementation '" + COORD + "'", 'exclude_original': {'group': 'io.antmedia', 'module': 'rtmp-client'},
                    'pom_dependencies': [], 'note': 'Use per-dependency exclusion of original io.antmedia RTMP in core and explicit implementation of candidate so published core POM carries it; do not use global substitution.'},
}
(EVIDENCE / 'rtmp-16k-candidate.json').write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + '\n')
# Include original and patched corresponding source, build recipe, and licenses for review/rebuild.
SOURCE_BUNDLE = DEST / (STEM + '-native-source.tar.gz')
with tarfile.open(SOURCE_BUNDLE, 'w:gz') as tar:
    for p in (ROOT / 'official-source-3af67842.tar.gz', ROOT / 'string-header.patch', ROOT / 'build-native.sh', ROOT / 'package-candidate.py', EVIDENCE / 'rtmp-16k-candidate.json'):
        tar.add(p, arcname=p.name)
    for p in sorted((SRC / 'rtmp-client').rglob('*')):
        if p.is_file():
            tar.add(p, arcname='patched-source/rtmp-client/' + str(p.relative_to(SRC / 'rtmp-client')))
    tar.add(SRC / 'LICENSE', arcname='patched-source/LICENSE')
for p in sorted(DEST.iterdir()):
    if p.is_file() and p.suffix not in ('.sha256', '.sha1', '.md5'):
        for algo in ('sha256', 'sha1', 'md5'):
            Path(str(p) + '.' + algo).write_text(sha(p, algo) + '\n')
(EVIDENCE / 'SHA256SUMS').write_text(''.join(sha(p) + '  ' + str(p.relative_to(ROOT)) + '\n' for p in sorted(DEST.iterdir()) if p.is_file() and p.suffix not in ('.sha256', '.sha1', '.md5')))
print(json.dumps({'coordinate': COORD, 'aar': str(AAR), 'sha256': sha(AAR), 'size': AAR.stat().st_size, 'evidence': str(EVIDENCE / 'rtmp-16k-candidate.json'), 'checks': checks}, indent=2))
