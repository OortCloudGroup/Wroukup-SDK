package com.router.base;

/**
 * 线程模式枚举
 * 定义 Action 执行的线程环境，类似 EventBus 的线程模型
 *
 * @author Zhang zhijun on 2026/5/13 9:39
 * @version 1.0
 */
public enum ThreadMode {
    /**
     *  posting 模式：在发送事件的同一线程执行
     *  性能最高，避免了线程切换开销
     *  适用于轻量级、非 UI 操作
     */
    POSTING,

    /**
     * 主线程模式：在 Android 主线程（UI 线程）执行
     *  如果当前已在主线程则直接执行，否则通过 Handler 切换
     *  适用于需要更新 UI 的操作
     */
    MAIN,

    /**
     * 后台线程模式：在后台线程执行
     *  如果当前不在主线程则直接执行，否则切换到后台线程
     *  适用于耗时操作，但需要避免与主线程频繁切换
     */
    BACKGROUND,

    /**
     * 异步线程模式：始终在独立的异步线程池执行
     *  每次调用都会使用新的线程
     *  适用于完全独立的耗时操作
     */
    ASYNC
}
