package com.router.base.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 拦截器注解
 * <p>
 * 标记在拦截器类上，编译器会自动生成对应的管理类。
 * </p>
 *
 * <h3>使用示例</h3>
 * <pre>{@code
 * // 全局拦截器（所有路由都会执行）
 * @Interceptor(priority = 1, global = true)
 * public class LogInterceptor implements ActionInterceptor { ... }
 *
 * // 模块拦截器（仅当前模块的路由执行）
 * @Interceptor(priority = 10, global = false)
 * public class LoginInterceptor implements ActionInterceptor { ... }
 * }</pre>
 */
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.CLASS)
public @interface Interceptor {
    /**
     * 优先级（数值越小优先级越高）
     * 默认值：50
     */
    int priority() default 50;

    /**
     * 是否为全局拦截器
     * <ul>
     *     <li>true: 所有路由都会执行此拦截器</li>
     *     <li>false: 仅所属模块的路由执行（默认）</li>
     * </ul>
     */
    boolean global() default false;
}
