package com.router.base.annotation;

import com.router.base.ThreadMode;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Action 路由注解
 * 用于标记跨模块通信的 Action 类，编译时会自动生成对应的 Module 注册代码
 * <p>
 * 使用示例：
 * <pre>
 * {@code
 * @Route(path = "login/action", threadMode = ThreadMode.MAIN)
 * public class LoginAction implements RouterAction {
 *     @Override
 *     public RouterResult invokeAction(Context context, Map<String, Object> requestData) {
 *         // 执行逻辑
 *         return new RouterResult.Builder().success().build();
 *     }
 * }
 * }
 * </pre>
 * </p>
 * @author Zhang zhijun on 2026/5/13 9:39
 * @version 1.0
 */
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.CLASS)
public @interface Route {

    /**
     * 路由路径，格式必须为：moduleName/actionName
     * 例如：login/action、circle/detail
     */
    String path();

    /**
     * 线程模式，指定 Action 的执行线程
     * POSTING: 在发送事件的同一线程执行（默认）
     * MAIN: 在主线程执行
     * BACKGROUND: 在后台线程执行
     * ASYNC: 在异步线程池执行
     */
    ThreadMode threadMode() default ThreadMode.POSTING;

    /**
     * 是否需要额外处理
     * true: 启用额外处理流程
     * false: 标准流程（默认）
     */
    boolean extraProcess() default false;
}
